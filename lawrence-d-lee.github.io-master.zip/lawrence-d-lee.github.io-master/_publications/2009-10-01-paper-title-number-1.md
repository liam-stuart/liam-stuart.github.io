---
title: "On the dimension and measure of inhomogeneous attractors"
collection: publications
permalink: 
excerpt: ''
date: 2-5-2018
venue: 'submitted.'
paperurl: 'https://arxiv.org/abs/1805.00887'
citation: ''
---
[arXiv](https://arxiv.org/abs/1805.00887)

---
title: "On the dimension and measure of inhomogeneous attractors"
collection: publications
permalink: 
excerpt: ''
date: 2-5-2018
venue: 'submitted.'
paperurl: 'https://arxiv.org/abs/1805.00887'
citation: ''
---
[arXiv](https://arxiv.org/abs/1805.00887)
