var addressPoints = [
  [
    "Loughborough, United Kingdom",
    52.7723859,
    -1.2077985
  ],
  [
    "St Andrews, Scotland",
    56.3403902,
    -2.7955844
  ],
  [
    "Edinburgh, Scotland",
    55.9496416,
    -3.1902352
  ],
  [
    "St Andrews, United Kingdom",
    56.3403902,
    -2.7955844
  ],
  [
    "Brechin, Scotland",
    56.7314911,
    -2.6600067
  ],
  [
    "Cape Town, South Africa",
    -33.928992,
    18.417396
  ],
  [
    "Cape Town, South Africa",
    -33.928993, 
    18.417396
  ],
  [
    "Stockholm, Sweden",
    59.3251172,
    18.0710935
  ]
];
