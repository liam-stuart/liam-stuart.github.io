---
title: "An introduction to inhomogeneous attractors"
collection: talks
permalink:
venue: "Pure Postgraduate Seminar, University of St Andrews"
date: 2018-04-23
location: "St Andrews, Scotland"
---
