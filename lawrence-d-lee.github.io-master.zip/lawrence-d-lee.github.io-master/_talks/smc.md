---
title: "Sequential Monte Carlo in population dynamics"
collection: talks
permalink:
venue: "School of Mathematics and Statistics, University of St Andrews"
date: 2016-04-24
location: "St Andrews, Scotland"
---
