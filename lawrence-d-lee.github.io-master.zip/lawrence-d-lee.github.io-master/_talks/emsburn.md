---
title: "How big are inhomogeneous attractors?"
collection: talks
permalink:
venue: "Edinburgh Mathematical Society PG Student Meeting, The Burn"
date: 2018-05-22
location: "Brechin, Scotland"
---
