---
title: "On the dimension and measure of inhomogeneous attractors"
collection: talks
permalink:
venue: "Pure Analyis Research Seminar, University of St Andrews"
date: 2018-04-24
location: "St Andrews, Scotland"
---
