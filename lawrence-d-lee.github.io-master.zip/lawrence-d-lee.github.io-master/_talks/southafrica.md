---
title: "Introduction to trace contrast methods"
collection: talks
permalink:
venue: "Estimating animal abundance and density using acoustic data workshop, University of Cape Town"
date: 2017-01-17
location: "Cape Town, South Africa"
---
