---
title: "A brief note on the dimension of inhomogeneous attractors"
collection: talks
permalink:
venue: "Dynamic Days Europe, University of Loughborough"
date: 2018-09-03
location: "Loughborough, United Kingdom"
---
