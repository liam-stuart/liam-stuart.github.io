---
title: "Trace contrast methods in acoustic space"
collection: talks
permalink:
venue: "African Institute for Mathematical Sciences"
date: 2017-01-20
location: "Cape Town, South Africa"
---
