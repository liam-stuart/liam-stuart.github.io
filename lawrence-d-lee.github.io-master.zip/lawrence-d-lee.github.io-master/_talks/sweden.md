---
title: "Inhomogeneous attractors and upper box dimension"
collection: talks
permalink:
venue: "Fractals and Dimensions, Mittag Leffler"
date: 2017-12-05
location: "Stockholm, Sweden"
---
