---
title: "Fractal geometry in nature and art"
collection: talks
permalink:
venue: "Carnegie Gathering, The Royal Society of Edinburgh"
date: 2018-02-07
location: "Edinburgh, Scotland"
---
