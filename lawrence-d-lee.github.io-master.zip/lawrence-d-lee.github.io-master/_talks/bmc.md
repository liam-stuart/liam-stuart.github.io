---
title: "A universal upper bound on the dimension of inhomogeneous attractors"
collection: talks
permalink:
venue: "British Mathematical Colloquium, University of St Andrews"
date: 2018-06-12
location: "St Andrews, United Kingdom"
---
