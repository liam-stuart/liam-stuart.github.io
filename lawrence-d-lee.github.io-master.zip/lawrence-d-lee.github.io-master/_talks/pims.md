---
title: "An introduction to iterated function systems"
collection: talks
permalink:
venue: "Postgraduate Interdisciplinary Mathematics Symposium, The Burn"
date: 2018-02-01
location: "Brechin, Scotland"
---
