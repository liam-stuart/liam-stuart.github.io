---
title: "Dimension of inhomogeneous self-conformal and self-affine sets"
collection: talks
permalink:
venue: "School of Mathematics and Statistics Research Day, University of St Andrews"
date: 2018-01-23
location: "St Andrews, Scotland"
---
