---
title: "Teaching"
permalink: /teaching/
author_profile: true
---
{% include base_path %}



## Teaching at St Andrews
### 2019 - 2020
Tutor for MT2502 Analysis, Autumn.


### 2018 - 2019
Tutor for MT1002 Mathematics, Spring.

Tutor for MT2502 Analysis, Autumn.


### 2017 - 2018
Tutor for MT1002 Mathematics, Spring.

Tutor for MT2502 Analysis, Autumn.


