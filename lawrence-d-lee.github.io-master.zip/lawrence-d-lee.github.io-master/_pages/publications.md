---
title: Publications
permalink: /publications/
author_profile: true
---

### Research Articles
[3] Lq-spectra of measures on planar non-conformal attractors (with K.J. Falconer, J.M. Fraser), [arXiv](https://arxiv.org/abs/2005.09361)  
*submitted.*

[2] Lq-spectra of self-affine measures: closed forms, counterexamples, and split binomial sums (with J.M. Fraser, I.D. Morris, Han Yu), [arXiv](https://arxiv.org/abs/1811.03400)  
*submitted.*

[1] Diophantine approximation on manifolds and lower bounds for Hausdorff dimension (with V. Beresnevich, R. C. Vaughan, S.Velani), [arXiv](https://arxiv.org/abs/1712.03761)  
**Mathematika, 63(2017), no.3, 762-779**.


{% include base_path %}


